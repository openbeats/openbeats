const ytdl = require("ytdl-core");

exports.handler = async (event) => {
    // TODO implement

    if (!event.queryStringParameters.vid) {
        const response = {
            statusCode: 200,
            body: JSON.stringify("vid not found"),
        };
        return response;
    }

    const vid = event.queryStringParameters.vid;
    // const info = await ytdl.getInfo(vid)
    const response = {
        statusCode: 200,
        body: JSON.stringify("response received"),
    };
    return response;

};